<?php
namespace Vdcstore\BuyNow\Helper;

class WishlistData extends \Magento\Wishlist\Helper\Data
{
   
    public function getAddToCartParams($item, $addReferer = false)
    {
        $params = $this->_getCartUrlParameters($item);
        $params[\Magento\Framework\App\ActionInterface::PARAM_NAME_URL_ENCODED] = '';

        if ($addReferer) {
            $params = $this->addRefererToParams($params);
        }

        return $this->_postDataHelper->getPostData(
            $this->_getUrlStore($item)->getUrl('buynow/index/cart'),
            $params
        );
    }
}
