<?php

namespace Vdcstore\BuyNow\Helper;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{

    const BUYNOW_BUTTON_TITLE = 'buynow/advance/button_title';


    const BUYNOW_BUTTON_DEFAULT_TITLE = 'Buy Now';


    const ADDTOCART_FORM_ID = 'product_addtocart_form';


    const KEEP_CART_PRODUCTS = 'buynow/advance/keep_product_incard';


    public function getConfig($config)
    {
        return $this->scopeConfig->getValue(
            $config,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    public function getButtonTitle()
    {
        $btnTitle = $this->getConfig(self::BUYNOW_BUTTON_TITLE);
        return $btnTitle ? $btnTitle : self::BUYNOW_BUTTON_DEFAULT_TITLE;
    }

    public function getAddToCartFormId()
    {
        return  self::ADDTOCART_FORM_ID;
    }

    public function keepCartProducts()
    {
        return $this->getConfig(self::KEEP_CART_PRODUCTS);
    }
}
